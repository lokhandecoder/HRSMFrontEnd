export interface DesignationModel {
    designationId: number;
    designationCode: string;
    designationName: string;
    isActive: boolean;
  }