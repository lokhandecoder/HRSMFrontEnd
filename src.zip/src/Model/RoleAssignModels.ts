export interface ColumnHeaderModel {
    roleAssignId: number;
    roleAssignName: string;
    isActive: boolean;
  }
  export interface RowHeaderModel {
    id: number;
    pageName: string;
    isActive: boolean;
  }
  
