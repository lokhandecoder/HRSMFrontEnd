export interface UserRoleMapping {
    roleAssignId: number;
    applicationPageId: number;
}