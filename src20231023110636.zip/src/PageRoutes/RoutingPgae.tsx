import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import DashBoardPage from "../Pages/DashBoardPage";
import LeavePage from "../Pages/LeavePage";
import StatusPage from "../Pages/StatusPage";
import AssignManager from "../Pages/AssignManager";
import EmployeePage from "../Pages/EmployeePage";
import EmployeesPage from "../Pages/EmployeesPage";


// import LeaveForm from '../Components/LeavePageComponent/LeaveForm'

function RoutingPgae() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<DashBoardPage />}></Route>
          <Route path="/leave/:id?" element={<LeavePage />} />
          <Route path="/status" element={<StatusPage />}></Route>
          <Route path="/assign" element={<AssignManager />}></Route>
          <Route path="/employee/:id?" element={<EmployeePage />} />
          <Route path="/employees" element={<EmployeesPage />} />

        </Routes>
      </BrowserRouter>
    </>
  );
}

export default RoutingPgae;