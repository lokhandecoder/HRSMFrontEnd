export interface LeaveStatus {
    leaveStatusId: number;
    leaveStatusName: string;
    leaveStatusNameCode: string;

  }