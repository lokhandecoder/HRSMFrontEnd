export interface GenderModel {
    genderId: number;
    genderCode: string;
    genderName: string;
    isActive: boolean;
  }
  