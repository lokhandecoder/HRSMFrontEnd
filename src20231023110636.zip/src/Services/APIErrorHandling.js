export function handleError(error, defaultMessage) {
    if (error.response && error.response.data && error.response.data.message) {
      throw new Error(error.response.data.message);
    } else {
      throw new Error(defaultMessage);
    }
  }